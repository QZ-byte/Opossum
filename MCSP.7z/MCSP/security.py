import os
import base64
import random
import string
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.fernet import Fernet, InvalidToken
from db import get_setting, update_setting

ITERATIONS = 200_000
SALT_KEY = "crypto_salt"
MARKER_KEY = "crypto_marker"
MARKER_PLAIN = b"master-check-v1"

def _get_or_create_salt():
    salt_b64 = get_setting(SALT_KEY)
    if salt_b64:
        return base64.b64decode(salt_b64)
    salt = os.urandom(16)
    update_setting(SALT_KEY, base64.b64encode(salt).decode())
    return salt

def derive_key(master_password: str) -> bytes:
    salt = _get_or_create_salt()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
    )
    return base64.urlsafe_b64encode(kdf.derive(master_password.encode()))

def get_cipher(master_password: str) -> Fernet:
    key = derive_key(master_password)
    cipher = Fernet(key)
    marker_enc = get_setting(MARKER_KEY)
    if marker_enc is None:
        token = cipher.encrypt(MARKER_PLAIN)
        update_setting(MARKER_KEY, base64.b64encode(token).decode())
        return cipher
    try:
        token = base64.b64decode(marker_enc)
        plain = cipher.decrypt(token)
        if plain != MARKER_PLAIN:
            raise InvalidToken()
        return cipher
    except InvalidToken:
        raise ValueError("Неверный мастер-пароль")

def encrypt_password(cipher: Fernet, plain: str) -> bytes:
    return cipher.encrypt(plain.encode())

def decrypt_password(cipher: Fernet, token: bytes) -> str:
    return cipher.decrypt(token).decode()

def generate_password(length=16):
    chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    return "".join(random.choice(chars) for _ in range(length))
