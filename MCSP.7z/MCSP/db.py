import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path("myplanner.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL,
        tags TEXT,
        format_meta TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        due_date TEXT,
        status TEXT DEFAULT 'pending',
        priority INTEGER DEFAULT 3,
        notes TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS passwords (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service TEXT NOT NULL,
        login TEXT NOT NULL,
        password_encrypted BLOB NOT NULL,
        updated_at TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()

# ----- Notes -----
def add_note(title, content, tags="", fmt_meta=""):
    conn = get_conn()
    conn.execute(
        "INSERT INTO notes(title, content, created_at, tags, format_meta) VALUES (?, ?, ?, ?, ?)",
        (title, content, datetime.utcnow().isoformat(), tags, fmt_meta)
    )
    conn.commit()
    conn.close()

def list_notes():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM notes ORDER BY created_at DESC").fetchall()
    conn.close()
    return rows

def get_note(note_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM notes WHERE id = ?", (note_id,)).fetchone()
    conn.close()
    return row

def update_note(note_id, title, content, tags, fmt_meta=""):
    conn = get_conn()
    conn.execute(
        "UPDATE notes SET title = ?, content = ?, tags = ?, format_meta = ? WHERE id = ?",
        (title, content, tags, fmt_meta, note_id)
    )
    conn.commit()
    conn.close()

def delete_note(note_id):
    conn = get_conn()
    conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    conn.commit()
    conn.close()

# ----- Tasks -----
def add_task(title, due_date=None, priority=3, notes=""):
    conn = get_conn()
    conn.execute(
        "INSERT INTO tasks(title, due_date, priority, notes) VALUES (?, ?, ?, ?)",
        (title, due_date, priority, notes)
    )
    conn.commit()
    conn.close()

def list_tasks():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM tasks ORDER BY due_date, id DESC").fetchall()
    conn.close()
    return rows

def update_task_status(task_id, status):
    conn = get_conn()
    conn.execute("UPDATE tasks SET status = ? WHERE id = ?", (status, task_id))
    conn.commit()
    conn.close()

def delete_task(task_id):
    conn = get_conn()
    conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()

# ----- Passwords -----
def add_password_record(service, login, password_encrypted):
    conn = get_conn()
    conn.execute(
        "INSERT INTO passwords(service, login, password_encrypted, updated_at) VALUES (?, ?, ?, ?)",
        (service, login, password_encrypted, datetime.utcnow().isoformat())
    )
    conn.commit()
    conn.close()

def list_password_records():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM passwords ORDER BY updated_at DESC").fetchall()
    conn.close()
    return rows

def delete_password_record(pid):
    conn = get_conn()
    conn.execute("DELETE FROM passwords WHERE id = ?", (pid,))
    conn.commit()
    conn.close()

# ----- Settings -----
def update_setting(key, value):
    conn = get_conn()
    conn.execute(
        "INSERT INTO settings(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value)
    )
    conn.commit()
    conn.close()

def get_setting(key):
    conn = get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    conn.close()
    return row["value"] if row else None
