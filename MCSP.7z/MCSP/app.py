import tkinter as tk
from tkinter import simpledialog, messagebox
from db import init_db
from security import get_cipher
from ui import App

def main():
    init_db()

    root = tk.Tk()
    root.withdraw()

    cipher = None
    while True:
        master = simpledialog.askstring("Мастер‑пароль", "Введите мастер‑пароль:", show="*", parent=root)
        if master is None:
            root.destroy()
            return
        try:
            cipher = get_cipher(master)
            break
        except ValueError:
            messagebox.showerror("Ошибка", "Неверный мастер‑пароль. Попробуйте ещё раз.", parent=root)

    app = App(root, cipher)
    root.deiconify()
    root.title("MyPlanner")
    root.geometry("920x600")
    root.mainloop()

if __name__ == "__main__":
    main()
