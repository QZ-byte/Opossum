import json
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, messagebox

# Supported inline styles (kept minimal for speed and stability)
STYLE_TAGS = ("bold", "italic", "underline", "strike")


# -------- metadata helpers --------
def parse_meta(meta_json: str):
    if not meta_json:
        return []
    try:
        data = json.loads(meta_json)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def offset_from_index(text: tk.Text, idx: str) -> int:
    # Offset of idx from start (1.0) by character count
    return len(text.get("1.0", idx))


def index_from_offset(off: int) -> str:
    # Convert char offset to Tk index
    return f"1.0+{off}c"


def meta_toggle_style(meta, start_off: int, end_off: int, style: str):
    if start_off >= end_off or style not in STYLE_TAGS:
        return meta
    new_meta = []
    removed = False
    for item in meta:
        r0, r1 = item["range"]
        st = item.get("style", [])
        # Overlap with selection and style present -> remove from overlap
        if not (end_off <= r0 or start_off >= r1) and style in st:
            if r0 < start_off:
                new_meta.append({"range": [r0, start_off], "style": st})
            if end_off < r1:
                new_meta.append({"range": [end_off, r1], "style": st})
            removed = True
        else:
            new_meta.append(item)
    if not removed:
        new_meta.append({"range": [start_off, end_off], "style": [style]})
    return new_meta


def render_tags_from_meta(text: tk.Text, meta, fonts):
    # Remove all style tags first
    for t in STYLE_TAGS:
        text.tag_remove(t, "1.0", "end")
    # Re-apply tags
    for item in meta:
        r0, r1 = item["range"]
        for style in item.get("style", []):
            if style in STYLE_TAGS:
                text.tag_add(style, index_from_offset(r0), index_from_offset(r1))
    # Ensure tag configurations link to stable fonts
    text.tag_configure("bold", font=fonts["bold"])
    text.tag_configure("italic", font=fonts["italic"])
    text.tag_configure("underline", underline=1)  # underline does not alter font family/size
    text.tag_configure("strike", overstrike=1)    # overstrike does not alter font family/size


class NoteDialog(tk.Toplevel):
    def __init__(self, parent, note_row, on_save):
        super().__init__(parent)
        self.title(note_row["title"])
        self.transient(parent)
        # No grab_set: allow interaction with all windows
        self.bind("<Button-1>", lambda e: self.lift())

        # Position near parent
        parent.update_idletasks()
        x = parent.winfo_x() + 40
        y = parent.winfo_y() + 40
        self.geometry(f"760x540+{x}+{y}")

        self.on_save = on_save
        self._tools_win = None

        # ------- stable fonts (one family/size; derivatives for bold/italic) -------
        base_default = tkfont.nametofont("TkDefaultFont")
        family = base_default.actual("family")
        size = base_default.actual("size")
        # Single base font object
        self.font_base = tkfont.Font(family=family, size=size)
        # Derivatives preserve family/size; only change weight/slant
        self.font_bold = tkfont.Font(family=family, size=size, weight="bold")
        self.font_italic = tkfont.Font(family=family, size=size, slant="italic")
        # Store for tag configuration reuse
        self._fonts = {"bold": self.font_bold, "italic": self.font_italic}

        # ------- layout -------
        self.columnconfigure(1, weight=1)
        self.rowconfigure(3, weight=1)

        ttk.Label(self, text="Заголовок:").grid(row=0, column=0, sticky="w", padx=6, pady=4)
        self.e_title = ttk.Entry(self)
        self.e_title.grid(row=0, column=1, sticky="ew", padx=6, pady=4)
        self.e_title.insert(0, note_row["title"])

        ttk.Label(self, text="Теги:").grid(row=1, column=0, sticky="w", padx=6, pady=4)
        self.e_tags = ttk.Entry(self)
        self.e_tags.grid(row=1, column=1, sticky="ew", padx=6, pady=4)
        self.e_tags.insert(0, note_row["tags"] or "")

        # Header + Tools toggle button under header
        hdr = ttk.Frame(self)
        hdr.grid(row=2, column=1, sticky="ew", padx=6)
        ttk.Label(self, text="Содержимое:").grid(row=2, column=0, sticky="w", padx=6)
        ttk.Button(hdr, text="Инструменты", command=self._toggle_tools_window).pack(side="left")

        # Text widget (stable base font)
        self.t_content = tk.Text(self, wrap="word", undo=True, maxundo=1000)
        self.t_content.grid(row=3, column=1, sticky="nsew", padx=6, pady=(2, 6))
        # Set a single base font to the widget to avoid jumps
        self.t_content.configure(font=self.font_base)
        self.t_content.insert("1.0", note_row["content"])

        s = ttk.Scrollbar(self, command=self.t_content.yview)
        s.grid(row=3, column=2, sticky="ns", pady=(2, 6))
        self.t_content.config(yscrollcommand=s.set)

        # Tag configs linked to stable fonts (see render_tags_from_meta)
        self.t_content.tag_configure("bold", font=self.font_bold)
        self.t_content.tag_configure("italic", font=self.font_italic)
        self.t_content.tag_configure("underline", underline=1)
        self.t_content.tag_configure("strike", overstrike=1)

        # Clipboard bindings: generate once and stop default to avoid double paste
        self._bind_clipboard_shortcuts(self.t_content)

        # Restore metadata formatting safely
        meta_raw = note_row["format_meta"] or ""
        self.format_meta = parse_meta(meta_raw)
        render_tags_from_meta(self.t_content, self.format_meta, self._fonts)

        # Bottom buttons
        btns = ttk.Frame(self)
        btns.grid(row=4, column=1, sticky="e", padx=6, pady=6)
        ttk.Button(btns, text="Сохранить", command=self._save).pack(side="left", padx=4)
        ttk.Button(btns, text="Закрыть", command=self.destroy).pack(side="left", padx=4)

        # -------- clipboard (как в Notepad++) --------
    def _bind_clipboard_shortcuts(self, widget: tk.Text):
        # Копировать
        widget.bind("<Control-c>", lambda e: (widget.event_generate("<<Copy>>"), "break"))
        widget.bind("<Control-C>", lambda e: (widget.event_generate("<<Copy>>"), "break"))
        widget.bind("<Control-Insert>", lambda e: (widget.event_generate("<<Copy>>"), "break"))

        # Вырезать
        widget.bind("<Control-x>", lambda e: (widget.event_generate("<<Cut>>"), "break"))
        widget.bind("<Control-X>", lambda e: (widget.event_generate("<<Cut>>"), "break"))
        widget.bind("<Shift-Delete>", lambda e: (widget.event_generate("<<Cut>>"), "break"))

        # Вставить
        widget.bind("<Control-v>", lambda e: (widget.event_generate("<<Paste>>"), "break"))
        widget.bind("<Control-V>", lambda e: (widget.event_generate("<<Paste>>"), "break"))
        widget.bind("<Shift-Insert>", lambda e: (widget.event_generate("<<Paste>>"), "break"))


    # -------- tools window (toggle, columnar) --------
    def _toggle_tools_window(self):
        if self._tools_win and self._tools_win.winfo_exists():
            self._tools_win.destroy()
            return

        win = tk.Toplevel(self)
        win.title("Инструменты")
        win.transient(self)
        win.bind("<Button-1>", lambda e: win.lift())
        self.update_idletasks()
        x = self.winfo_x() + 30
        y = self.winfo_y() + 30
        win.geometry(f"+{x}+{y}")
        self._tools_win = win

        grid = ttk.Frame(win)
        grid.pack(fill="x", padx=8, pady=8)
        for c in range(2):
            grid.grid_columnconfigure(c, weight=1)

        ttk.Label(grid, text="Стиль текста").grid(row=0, column=0, sticky="w", pady=(0, 4))
        ttk.Label(grid, text="Сервисные действия").grid(row=0, column=1, sticky="w", pady=(0, 4))

        # Column 0: styles
        col0 = ttk.Frame(grid)
        col0.grid(row=1, column=0, sticky="nw")
        for label, style in [("Полужирный", "bold"), ("Курсив", "italic"), ("Подчёркнутый", "underline"), ("Зачёркнутый", "strike")]:
            ttk.Button(col0, text=label, width=16, command=lambda s=style: self._apply_style_toggle(s)).pack(anchor="w", pady=2)

        # Column 1: utilities
        col1 = ttk.Frame(grid)
        col1.grid(row=1, column=1, sticky="nw")
        ttk.Button(col1, text="Очистить форматирование выделения", width=30, command=self._clear_selection_styles).pack(anchor="w", pady=2)
        ttk.Button(col1, text="Закрыть инструменты", width=30, command=win.destroy).pack(anchor="w", pady=2)

    # -------- style application via metadata --------
    def _apply_style_toggle(self, style: str):
        try:
            start_idx = self.t_content.index("sel.first")
            end_idx = self.t_content.index("sel.last")
        except tk.TclError:
            return
        start_off = offset_from_index(self.t_content, start_idx)
        end_off = offset_from_index(self.t_content, end_idx)
        self.format_meta = meta_toggle_style(self.format_meta, start_off, end_off, style)
        render_tags_from_meta(self.t_content, self.format_meta, self._fonts)

    def _clear_selection_styles(self):
        try:
            start_idx = self.t_content.index("sel.first")
            end_idx = self.t_content.index("sel.last")
        except tk.TclError:
            return
        start_off = offset_from_index(self.t_content, start_idx)
        end_off = offset_from_index(self.t_content, end_idx)
        new_meta = []
        for item in self.format_meta:
            r0, r1 = item["range"]
            st = item.get("style", [])
            # Overlap -> remove styles from overlap by splitting
            if not (end_off <= r0 or start_off >= r1):
                if r0 < start_off:
                    new_meta.append({"range": [r0, start_off], "style": st})
                if end_off < r1:
                    new_meta.append({"range": [end_off, r1], "style": st})
            else:
                new_meta.append(item)
        self.format_meta = new_meta
        render_tags_from_meta(self.t_content, self.format_meta, self._fonts)

    # -------- save --------
    def _save(self):
        title = self.e_title.get().strip()
        tags = self.e_tags.get().strip()
        content = self.t_content.get("1.0", "end").strip()
        if not title:
            messagebox.showwarning("Валидация", "Введите заголовок.")
            return
        fmt_meta_json = json.dumps(self.format_meta, ensure_ascii=False)
        self.on_save(title, content, tags, fmt_meta_json)
        if self._tools_win and self._tools_win.winfo_exists():
            self._tools_win.destroy()
        self.destroy()
