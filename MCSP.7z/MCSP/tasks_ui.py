import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from db import add_task, list_tasks, update_task_status, delete_task

class TasksTab:
    def __init__(self, parent):
        self.frame = ttk.Frame(parent)
        self.frame.grid_columnconfigure(0, weight=1)
        self.frame.grid_rowconfigure(1, weight=1)

        top = ttk.Frame(self.frame)
        top.grid(row=0, column=0, sticky="ew", padx=5, pady=4)
        for i in range(9):
            top.grid_columnconfigure(i, weight=0)
        top.grid_columnconfigure(1, weight=1)

        ttk.Label(top, text="Задача:").grid(row=0, column=0, padx=2)
        self.task_title = ttk.Entry(top)
        self.task_title.grid(row=0, column=1, padx=2, sticky="ew")

        ttk.Label(top, text="Дата:").grid(row=0, column=2, padx=2)
        self.task_due = ttk.Entry(top, width=12)
        self.task_due.grid(row=0, column=3, padx=2)
        self.task_due.insert(0, "YYYY-MM-DD")

        ttk.Label(top, text="P:").grid(row=0, column=4, padx=2)
        self.task_prio = ttk.Spinbox(top, from_=1, to=5, width=4)
        self.task_prio.grid(row=0, column=5, padx=2)
        self.task_prio.delete(0, "end")
        self.task_prio.insert(0, "3")

        ttk.Button(top, text="Добавить", width=10, command=self._add_task).grid(row=0, column=6, padx=2)
        ttk.Button(top, text="Выполнено", width=10, command=self._complete_task).grid(row=0, column=7, padx=2)
        ttk.Button(top, text="Удалить", width=8, command=self._delete_task).grid(row=0, column=8, padx=2)

        list_frame = ttk.Frame(self.frame)
        list_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(list_frame, columns=("title", "due", "prio", "status"), show="headings", height=18)
        self.tree.heading("title", text="Задача")
        self.tree.heading("due", text="Дедлайн")
        self.tree.heading("prio", text="P")
        self.tree.heading("status", text="Статус")
        self.tree.column("title", width=480, anchor="w")
        self.tree.column("due", width=120, anchor="center")
        self.tree.column("prio", width=40, anchor="center")
        self.tree.column("status", width=100, anchor="center")
        self.tree.grid(row=0, column=0, sticky="nsew")

        s = ttk.Scrollbar(list_frame, command=self.tree.yview)
        s.grid(row=0, column=1, sticky="ns")
        self.tree.config(yscrollcommand=s.set)

        self._refresh()

    def _refresh(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for row in list_tasks():
            self.tree.insert("", "end", iid=row["id"], values=(row["title"], row["due_date"] or "-", row["priority"], row["status"]))

    def _add_task(self):
        title = self.task_title.get().strip()
        due_str = self.task_due.get().strip()
        prio = int(self.task_prio.get() or 3)
        if not title:
            messagebox.showwarning("Валидация", "Введите название задачи.")
            return
        due_val = None
        if due_str:
            try:
                dt = datetime.strptime(due_str, "%Y-%m-%d")
                due_val = dt.date().isoformat()
            except ValueError:
                messagebox.showwarning("Валидация", "Дата должна быть в формате YYYY-MM-DD.")
                return
        add_task(title, due_val, prio)
        self._refresh()

    def _complete_task(self):
        sel = self.tree.selection()
        if not sel:
            return
        task_id = int(sel[0])
        update_task_status(task_id, "done")
        self._refresh()

    def _delete_task(self):
        sel = self.tree.selection()
        if not sel:
            return
        task_id = int(sel[0])
        if messagebox.askyesno("Удалить", "Удалить выбранную задачу?"):
            delete_task(task_id)
            self._refresh()
