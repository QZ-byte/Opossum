import tkinter as tk
from tkinter import ttk
from notes_ui import NotesTab
from tasks_ui import TasksTab
from passwords_ui import PasswordsTab

class App:
    def __init__(self, root, cipher):
        self.root = root
        self.cipher = cipher

        style = ttk.Style()
        style.configure("Treeview", rowheight=20)
        style.configure("TButton", padding=(4, 2))
        style.configure("TEntry", padding=(2, 1))

        notebook = ttk.Notebook(root)
        notebook.grid(row=0, column=0, sticky="nsew")

        self.notes_tab = NotesTab(notebook)
        self.tasks_tab = TasksTab(notebook)
        self.passwords_tab = PasswordsTab(notebook, cipher)

        notebook.add(self.notes_tab.frame, text="Заметки")
        notebook.add(self.tasks_tab.frame, text="Задачи")
        notebook.add(self.passwords_tab.frame, text="Пароли")

        root.rowconfigure(0, weight=1)
        root.columnconfigure(0, weight=1)
