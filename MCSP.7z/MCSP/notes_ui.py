import tkinter as tk
from tkinter import ttk, messagebox
from db import add_note, list_notes, get_note, update_note, delete_note
from note_dialog import NoteDialog

class NotesTab:
    def __init__(self, parent):
        self.frame = ttk.Frame(parent)
        self.frame.grid_columnconfigure(0, weight=1)
        self.frame.grid_rowconfigure(1, weight=1)

        top = ttk.Frame(self.frame)
        top.grid(row=0, column=0, sticky="ew", padx=5, pady=4)
        for i in range(7):
            top.grid_columnconfigure(i, weight=0)
        top.grid_columnconfigure(1, weight=1)

        ttk.Label(top, text="Заг:").grid(row=0, column=0, padx=2)
        self.note_title = ttk.Entry(top)
        self.note_title.grid(row=0, column=1, padx=2, sticky="ew")

        ttk.Label(top, text="Теги:").grid(row=0, column=2, padx=2)
        self.note_tags = ttk.Entry(top, width=18)
        self.note_tags.grid(row=0, column=3, padx=2)

        ttk.Button(top, text="Добавить", width=10, command=self._add_note).grid(row=0, column=4, padx=2)
        ttk.Button(top, text="Открыть", width=8, command=self._open_note).grid(row=0, column=5, padx=2)
        ttk.Button(top, text="Удалить", width=8, command=self._delete_note).grid(row=0, column=6, padx=2)

        list_frame = ttk.Frame(self.frame)
        list_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(list_frame, columns=("title", "tags", "created"), show="headings", height=18)
        self.tree.heading("title", text="Заголовок")
        self.tree.heading("tags", text="Теги")
        self.tree.heading("created", text="Создано")
        self.tree.column("title", width=480, anchor="w")
        self.tree.column("tags", width=160, anchor="w")
        self.tree.column("created", width=140, anchor="center")
        self.tree.grid(row=0, column=0, sticky="nsew")

        s2 = ttk.Scrollbar(list_frame, command=self.tree.yview)
        s2.grid(row=0, column=1, sticky="ns")
        self.tree.config(yscrollcommand=s2.set)

        self.tree.bind("<Double-1>", self._open_note)
        self._refresh()

    def _refresh(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for row in list_notes():
            self.tree.insert("", "end", iid=row["id"], values=(row["title"], row["tags"] or "", row["created_at"]))

    def _add_note(self):
        title = self.note_title.get().strip()
        tags = self.note_tags.get().strip()
        if not title:
            messagebox.showwarning("Валидация", "Введите заголовок.")
            return
        add_note(title, "", tags, fmt_meta="")
        self._refresh()

    def _open_note(self, event=None):
        note_id = None
        sel = self.tree.selection()
        if sel:
            note_id = int(sel[0])
        elif event is not None:
            item = self.tree.identify_row(event.y)
            if item:
                note_id = int(item)
        if note_id is None:
            return

        row = get_note(note_id)
        if not row:
            return

        NoteDialog(self.frame, row, on_save=lambda t, c, tags, fmt_meta: (
            update_note(row["id"], t, c, tags, fmt_meta),
            self._refresh()
        ))

    def _delete_note(self):
        sel = self.tree.selection()
        if not sel:
            return
        note_id = int(sel[0])
        if messagebox.askyesno("Удалить", "Удалить выбранную заметку?"):
            delete_note(note_id)
            self._refresh()
