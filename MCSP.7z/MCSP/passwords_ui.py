import tkinter as tk
from tkinter import ttk, messagebox
from db import add_password_record, list_password_records, delete_password_record, get_conn
from security import encrypt_password, decrypt_password, generate_password

class PasswordsTab:
    def __init__(self, parent, cipher):
        self.cipher = cipher
        self.frame = ttk.Frame(parent)
        self.frame.grid_columnconfigure(0, weight=1)
        self.frame.grid_rowconfigure(1, weight=1)

        top = ttk.Frame(self.frame)
        top.grid(row=0, column=0, sticky="ew", padx=5, pady=4)
        for i in range(10):
            top.grid_columnconfigure(i, weight=0)
        top.grid_columnconfigure(1, weight=1)

        ttk.Label(top, text="Сервис:").grid(row=0, column=0, padx=2)
        self.e_service = ttk.Entry(top, width=18)
        self.e_service.grid(row=0, column=1, padx=2, sticky="ew")

        ttk.Label(top, text="Логин:").grid(row=0, column=2, padx=2)
        self.e_login = ttk.Entry(top, width=18)
        self.e_login.grid(row=0, column=3, padx=2)

        ttk.Label(top, text="Пароль:").grid(row=0, column=4, padx=2)
        self.e_password = ttk.Entry(top, width=18, show="*")
        self.e_password.grid(row=0, column=5, padx=2)

        ttk.Button(top, text="Gen", width=5, command=self._gen).grid(row=0, column=6, padx=2)
        ttk.Button(top, text="Сохранить", width=10, command=self._add).grid(row=0, column=7, padx=2)
        ttk.Button(top, text="Показать", width=10, command=self._show).grid(row=0, column=8, padx=2)
        ttk.Button(top, text="Удалить", width=8, command=self._delete).grid(row=0, column=9, padx=2)

        list_frame = ttk.Frame(self.frame)
        list_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(list_frame, columns=("service", "login", "updated"), show="headings", height=18)
        self.tree.heading("service", text="Сервис")
        self.tree.heading("login", text="Логин")
        self.tree.heading("updated", text="Обновл.")
        self.tree.column("service", width=300, anchor="w")
        self.tree.column("login", width=260, anchor="w")
        self.tree.column("updated", width=120, anchor="center")
        self.tree.grid(row=0, column=0, sticky="nsew")

        s = ttk.Scrollbar(list_frame, command=self.tree.yview)
        s.grid(row=0, column=1, sticky="ns")
        self.tree.config(yscrollcommand=s.set)

        self._refresh()

    def _gen(self):
        pwd = generate_password(16)
        self.e_password.delete(0, "end")
        self.e_password.insert(0, pwd)

    def _add(self):
        service = self.e_service.get().strip()
        login = self.e_login.get().strip()
        plain = self.e_password.get().strip()
        if not service or not login or not plain:
            messagebox.showwarning("Валидация", "Заполните сервис, логин и пароль.")
            return
        token = encrypt_password(self.cipher, plain)
        add_password_record(service, login, token)
        self.e_password.delete(0, "end")
        self._refresh()

    def _refresh(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for row in list_password_records():
            self.tree.insert("", "end", iid=row["id"], values=(row["service"], row["login"], row["updated_at"]))

    def _show(self):
        sel = self.tree.selection()
        if not sel:
            return
        pid = int(sel[0])
        conn = get_conn()
        row = conn.execute("SELECT password_encrypted FROM passwords WHERE id = ?", (pid,)).fetchone()
        conn.close()
        plain = decrypt_password(self.cipher, row["password_encrypted"])
        messagebox.showinfo("Пароль", plain)

    def _delete(self):
        sel = self.tree.selection()
        if not sel:
            return
        pid = int(sel[0])
        if messagebox.askyesno("Удалить", "Удалить выбранный пароль?"):
            delete_password_record(pid)
            self._refresh()
